=====================================
    QUICKVOICE VERSION 1.0 README
=====================================

To be able to pin QuickVoice
to start menu and search it easily,
run the "Create shortcut in start
menu" file.

Thank you for downloading QuickVoice!